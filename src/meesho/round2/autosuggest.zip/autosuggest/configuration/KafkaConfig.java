package meesho.round2.autosuggest.configuration;

public class KafkaConfig {

    private String url;

    private String key;


}
