package meesho.round2.autosuggest.exception;

public class PrefixNotFoundException extends AutoSuggestServicException {
    public PrefixNotFoundException(String message) {
        super(message);
    }
}
