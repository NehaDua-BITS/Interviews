package meesho.round2.autosuggest.exception;

public class AutoSuggestServicException extends RuntimeException {
    public AutoSuggestServicException(String message) {
        super(message);
    }
}
